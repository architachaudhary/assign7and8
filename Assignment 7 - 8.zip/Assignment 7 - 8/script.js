document.addEventListener('DOMContentLoaded', function() {
    // Get references to DOM elements
    const rollButton = document.getElementById('roll-button');
    const dice1 = document.getElementById('dice1');
    const dice2 = document.getElementById('dice2');
    const player1ScoreDisplay = document.getElementById('player1-score');
    const player2ScoreDisplay = document.getElementById('player2-score');
    const winnerMessage = document.getElementById('winner-message');

    // Initialize player scores
    let player1Score = 0;
    let player2Score = 0;

    // Function to roll the dice and update scores
    function rollDice() {

        // Generate random values for the two dice
        const dice1Value = Math.floor(Math.random() * 6) + 1;
        const dice2Value = Math.floor(Math.random() * 6) + 1;

        // Update the dice images
        dice1.src = `dice${dice1Value}.png`;
        dice2.src = `dice${dice2Value}.png`;

        // Calculate the score difference between the two dice
        const scoreDifference = Math.abs(dice1Value - dice2Value);
        
        // Update player scores based on the score difference
        if (dice1Value > dice2Value) {
            player1Score += scoreDifference;
        } else if (dice2Value > dice1Value) {
            player2Score += scoreDifference;
        }

        // Update the score display
        updateScore();

        // Check if there is a winner
        checkWinner();
    }

    // Function to update the score display
    function updateScore() {
        player1ScoreDisplay.textContent = `Player 1 Score: ${player1Score}`;
        player2ScoreDisplay.textContent = `Player 2 Score: ${player2Score}`;
    }

    // Function to check if there is a winner
    function checkWinner() {

        // Change this to your desired winning score
        const winningScore = 20; 
        if (player1Score >= winningScore) {
            winnerMessage.textContent = 'Player 1 wins!';
            rollButton.disabled = true;
        } else if (player2Score >= winningScore) {
            winnerMessage.textContent = 'Player 2 wins!';
            rollButton.disabled = true;
        }
    }

    // Event listener for the roll button
    rollButton.addEventListener('click', rollDice);
});
